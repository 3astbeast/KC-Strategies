#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
    public class HiLoBands : Indicator
    {
		private RSI RSI1;
		private bool rsiUp;
		private bool rsiDown;
		
		private Momentum Momentum1;
		private bool momoUp;
		private bool momoDown;		
		
		private bool midlineUp;
		private bool midlineDown;
		
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Draw highest high and lowest low within the last x number of bars.";
                Name = "HiLoBands";
                Calculate = Calculate.OnPriceChange;
                IsOverlay = true;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = true;
                DrawVerticalGridLines = true;
                PaintPriceMarkers = true;
                ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                IsSuspendedWhileInactive = true;

                LookbackPeriod = 4; 
                Width = 2;

                AddPlot(Brushes.Lime, "HighestHigh"); 
                AddPlot(Brushes.Red, "LowestLow");     
                AddPlot(Brushes.LightGray, "MiddleLine"); 
            }
            else if (State == State.Configure)
            {
                Plots[0].Width = Width; 
                Plots[1].Width = Width; 
				Plots[2].Width = Width; 
            }
            else if (State == State.DataLoaded)
            {
                RSI1 		= RSI(Close, 14, 3);
				Momentum1	= Momentum(Close, 14);
            }
        }

        protected override void OnBarUpdate()
        {
            // Ensure we have enough bars for this indicator's own calculations (MAX/MIN lookback)
            // and for the dependent indicators (RSI and Momentum usually have their own internal warm-up periods,
            // but NinjaTrader handles this. The primary concern here is LookbackPeriod for MAX/MIN).
            if (CurrentBar < LookbackPeriod) // LookbackPeriod for MAX/MIN
                return;
			
			// Additional check: Ensure CurrentBar is also sufficient for RSI(14) and Momentum(14)
            // A common safe check is `CurrentBar < Math.Max(LookbackPeriod, Math.Max(rsiPeriod, momentumPeriod))`
            // For simplicity, if RSI/Momentum periods are small or similar to LookbackPeriod, the above check might be enough.
            // NinjaTrader will provide 0 or default values for indicators not yet "warmed up".
            // A more robust check for indicator values being "valid" is often done in the strategy consuming them.
            // Or, ensure LookbackPeriod is set to be >= the largest period of internal indicators if they are critical from bar 0 of HiLoBands' own calculation.
            // For now, the `CurrentBar < LookbackPeriod` is the direct check for this indicator's primary logic.

            if (RSI1 == null || Momentum1 == null) // Check if they were initialized
                 return;

            double highestHigh = MAX(High, LookbackPeriod)[0];
            double lowestLow = MIN(Low, LookbackPeriod)[0];
			double midlineVal = (highestHigh + lowestLow) / 2; 

            Values[0][0] = highestHigh; 
            Values[1][0] = lowestLow;   
			Values[2][0] = midlineVal;  
			
            // Accessing [0] of RSI1 and Momentum1 implies they have calculated a value for the current bar.
            // NinjaTrader handles providing valid (even if default/zero initially) values.
			momoUp = Momentum1[0] > Momentum1[1];
			momoDown = Momentum1[0] < Momentum1[1];
			
			rsiUp = RSI1[0] > RSI1[1];
			rsiDown = RSI1[0] < RSI1[1];
			
			midlineUp = Values[2][0] > Values[2][1] && Values[2][1] <= Values[2][2];
			midlineDown = Values[2][0] < Values[2][1] && Values[2][1] >= Values[2][2];
			
			// if (Low[1] == Values[1][1] && rsiUp && momoUp && midlineUp && Close[0] > Open[0])
			
			if (midlineUp && momoUp)
			{
				Draw.ArrowUp(this, "LE_Vis" + CurrentBar, false, 0, Low[0] - 5 * TickSize, Brushes.Cyan);				
			}
			
			// if (High[1] == Values[0][1] && rsiDown && momoDown && midlineDown && Close[0] < Open[0])
			
			if (midlineDown && momoDown)
			{
				Draw.ArrowDown(this, "SE_Vis" + CurrentBar, false, 0, High[0] + 5 * TickSize, Brushes.Yellow);
			}
        }

        #region Properties
		
        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Period", Description = "Number of bars to look back", Order = 1, GroupName = "Parameters")]
        public int LookbackPeriod { get; set; }
		
        [NinjaScriptProperty]
        [Display(Name = "Line Width", Order = 2, GroupName = "Parameters")]
        public int Width { get; set; }
		
        #endregion
    }
}

// Rest of the generated code remains the same...

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HiLoBands[] cacheHiLoBands;
		public HiLoBands HiLoBands(int lookbackPeriod, int width)
		{
			return HiLoBands(Input, lookbackPeriod, width);
		}

		public HiLoBands HiLoBands(ISeries<double> input, int lookbackPeriod, int width)
		{
			if (cacheHiLoBands != null)
				for (int idx = 0; idx < cacheHiLoBands.Length; idx++)
					if (cacheHiLoBands[idx] != null && cacheHiLoBands[idx].LookbackPeriod == lookbackPeriod && cacheHiLoBands[idx].Width == width && cacheHiLoBands[idx].EqualsInput(input))
						return cacheHiLoBands[idx];
			return CacheIndicator<HiLoBands>(new HiLoBands(){ LookbackPeriod = lookbackPeriod, Width = width }, input, ref cacheHiLoBands);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HiLoBands HiLoBands(int lookbackPeriod, int width)
		{
			return indicator.HiLoBands(Input, lookbackPeriod, width);
		}

		public Indicators.HiLoBands HiLoBands(ISeries<double> input , int lookbackPeriod, int width)
		{
			return indicator.HiLoBands(input, lookbackPeriod, width);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HiLoBands HiLoBands(int lookbackPeriod, int width)
		{
			return indicator.HiLoBands(Input, lookbackPeriod, width);
		}

		public Indicators.HiLoBands HiLoBands(ISeries<double> input , int lookbackPeriod, int width)
		{
			return indicator.HiLoBands(input, lookbackPeriod, width);
		}
	}
}

#endregion
