#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Forms;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.NinjaScript;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Strategies;
#endregion

namespace NinjaTrader.NinjaScript.Strategies.KCStrategies
{
    public class Casher : KCAlgoBase
    {
        // Parameters
		private Momentum Momentum1;
		
		private HiLoBands HiLoBands1; 
        private Series<double> highestHigh;
        private Series<double> lowestLow;
		private Series<double> midline;
		
		private bool longSignal = false;
        private bool shortSignal = false;

		public override string DisplayName { get { return Name; } }
		
        protected override void OnStateChange()
        {
            base.OnStateChange();

            if (State == State.SetDefaults)
            {
                Description = "This strategy is based on the HiLoBands indicator.";
                Name = "Casher v5.4.4";
                StrategyName = "Casher";
                Version = "5.4.4 May 2025";
                Credits = "Strategy by Khanh Nguyen";
                ChartType = "Tbars 25 or 50";
				
				LookbackPeriod		= 4;
				Width				= 2;
				showHighLow			= true;				
				
		        enableHmaHooks 		= false;
		        showHmaHooks 		= false;
				
		        enableVMA 			= false;
		        showVMA 			= false;

		        enableRegChan1 		= false;
		        enableRegChan2 		= false;
		        showRegChan1 		= false;
		        showRegChan2 		= false;
		        showRegChanHiLo 	= false;
				
				RiskToReward		= 1.5;
				RiskRewardRatio		= RiskToReward;
				TrailOffset			= 2;
            }
            else if (State == State.DataLoaded)
            {
				highestHigh = new Series<double> (this);
				lowestLow = new Series<double> (this);
				midline = new Series<double> (this);
				
                InitializeIndicators();
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBars[0] < BarsRequiredToTrade)
                return;
            
			// Ensure there are enough bars to calculate the average range
		    if (CurrentBar < LookbackPeriod)
		        return;
		
			highestHigh[0] = HiLoBands1.Values[0][0];
			lowestLow[0] = HiLoBands1.Values[1][0];
			midline[0] = HiLoBands1.Values[2][0];
			
			longSignal = ((midline[0] > midline[1] && midline[1] <= midline[2])
				|| (midline[0] > midline[1]))
				&& (Momentum1[0] > Momentum1[1]);
			
			shortSignal = ((midline[0] < midline[1] && midline[1] >= midline[2])
				|| (midline[0] < midline[1]))
				&&  (Momentum1[0] < Momentum1[1]); 
			
//		    longSignal = ((highestHigh[0] > highestHigh[1] && highestHigh[1] <= highestHigh[2])
//		        || (midline[0] > midline[1] && midline[1] <= midline[2])
//		        || (Low[0] > midline[0] && Low[1] <= midline[1])
//		        || (Low[0] > Low[1] && Low[1] <= lowestLow[1]) 
//		        || (Close[0] > midline[0] && Close[1] <= midline[1])
//				|| (midline[0] > midline[1]))
//		        && (Close[0] > Close[1]) && (Close[0] > Open[0])
//		        && (Momentum1[0] > Momentum1[1] && Momentum1[0] > 0);
		    
//		    shortSignal = ((lowestLow[0] < lowestLow[1] && lowestLow[1] >= lowestLow[2])
//		        || (midline[0] < midline[1] && midline[1] >= midline[2])
//		        || (High[0] < midline[0] && High[1] >= midline[1])
//		        || (High[0] < High[1] && High[1] >= highestHigh[1]) 
//		        || (Close[0] < midline[0] && Close[1] >= midline[1])
//				|| (midline[0] < midline[1]))
//		        && (Close[0] < Close[1]) && (Close[0] < Open[0])
//		        && (Momentum1[0] < Momentum1[1] && Momentum1[0] < 0);    
		    
			// Set trailing stop at previous lowest low for long and highest hig for short and profit target at RiskRewardRatio * .
			if (isFlat) 
            {
                if (longSignal)
                {
                    double stopRiskDistanceInPrice = Close[0] - lowestLow[1];
                    if (stopRiskDistanceInPrice > (TickSize * 0.5) && TickSize > 0) 
                    {
                        InitialStop = (int)Math.Max(1.0, Math.Round(stopRiskDistanceInPrice / TickSize)) - TrailOffset;
                        if (RiskRewardRatio > 0)
                        {
                            double profitTargetDistanceInTicks = InitialStop * RiskRewardRatio;
                            ProfitTarget = (int)Math.Max(1.0, Math.Round(profitTargetDistanceInTicks));
                        }
                    }
                }
                else if (shortSignal)
                {
                    double stopRiskDistanceInPrice = highestHigh[1] - Close[0];
                    if (stopRiskDistanceInPrice > (TickSize * 0.5) && TickSize > 0) 
                    {
                        InitialStop = (int)Math.Max(1.0, Math.Round(stopRiskDistanceInPrice / TickSize)) + TrailOffset;
                        if (RiskRewardRatio > 0)
                        {
                            double profitTargetDistanceInTicks = InitialStop * RiskRewardRatio;
                            ProfitTarget = (int)Math.Max(1.0, Math.Round(profitTargetDistanceInTicks));
                        }
                    }
                }
            }
			
			base.OnBarUpdate();
        }

        protected override bool ValidateEntryLong()
        {
            // Logic for validating long entries
			if (longSignal) return true;
			else return false;
        }

        protected override bool ValidateEntryShort()
        {
            // Logic for validating short entries
			if (shortSignal) return true;
            else return false;
        }

//       	protected override bool ValidateExitLong()
//        {
//            // Logic for validating long exits
//            return enableExit? true: false;
//        }

//        protected override bool ValidateExitShort()
//        {
//			// Logic for validating short exits
//			return enableExit? true: false;
//        }

        #region Indicators
        protected override void InitializeIndicators()
        {
			HiLoBands1				= HiLoBands(LookbackPeriod, Width);
			HiLoBands1.Plots[0].Brush = Brushes.Cyan;
			HiLoBands1.Plots[1].Brush = Brushes.Magenta;
			if (showHighLow) AddChartIndicator(HiLoBands1);
			
			Momentum1			= Momentum(Close, 14);	
			Momentum1.Plots[0].Brush = Brushes.Yellow;
			Momentum1.Plots[0].Width = 2;
			if (showMomo) AddChartIndicator(Momentum1);
        }
        #endregion

        #region Properties
		
		[NinjaScriptProperty]
        [Display(Name = "Risk to Reward Ratio", Order = 1, GroupName="02. Order Settings")]
        public double RiskToReward { get; set; }		
		
		[NinjaScriptProperty]
        [Display(Name = "HiLo Period", Order = 1, GroupName="08a. Strategy Settings")]
        public int LookbackPeriod { get; set; }		
		
		[NinjaScriptProperty]
        [Display(Name = "Line Width", Order = 2, GroupName="08a. Strategy Settings")]
        public int Width { get; set; }	
		
		[NinjaScriptProperty]
        [Display(Name = "Show High Low Bands", Order = 3, GroupName = "08a. Strategy Settings")]
        public bool showHighLow { get; set; }
		
		[NinjaScriptProperty]
        [Display(Name = "Show Momentum", Order = 4, GroupName = "08a. Strategy Settings")]
        public bool showMomo { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Trail Stop Tick Offset", Order = 5, GroupName="08a. Strategy Settings")]
		public int TrailOffset
		{ get; set; }

        #endregion
    }
}
